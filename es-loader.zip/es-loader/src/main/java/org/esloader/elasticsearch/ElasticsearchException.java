package org.esloader.elasticsearch;

public class ElasticsearchException extends RuntimeException {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * Construct a <code>ElasticsearchException</code> with the specified cause exception.
     */
    public ElasticsearchException(Throwable cause) {
        super(cause);
    }

	public ElasticsearchException(String message) {
		super(message);
	}

	public ElasticsearchException(String message, Throwable cause) {
		super(message, cause);
	}
}
