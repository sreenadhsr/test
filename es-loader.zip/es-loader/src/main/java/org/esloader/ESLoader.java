package org.esloader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.beanio.BeanReader;
import org.beanio.StreamFactory;
import org.elasticsearch.client.RestClient;
import org.esloader.index.action.BulkProcessor;
import org.esloader.index.bean.IndexAware;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch.core.BulkRequest;
import co.elastic.clients.elasticsearch.core.BulkResponse;
import co.elastic.clients.elasticsearch.core.bulk.BulkResponseItem;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;

public class ESLoader {

	Logger logger = LoggerFactory.getLogger(ESLoader.class);
	
	ElasticsearchClient esClient = null;
	
	public static void main(String[] args) throws ElasticsearchException, IOException {
		ESLoader esLoader = new ESLoader();
		esLoader.buildEsClient();
		//esLoader.loadFromFile_2("C:\\Users\\sreen\\Development\\es_test_data\\title.akas.data.tsv", "src/main/resources/index-mapping.xml", "akasFile", "akas");
		//esLoader.loadFromFile_1("C:\\Users\\sreen\\Development\\es_test_data\\title.akas.data.tsv", "src/main/resources/index-mapping.xml", "akasFile", "akas");
		esLoader.loadFromFile_1("C:\\Users\\sreen\\Development\\es_test_data\\name.basics.data.tsv", "src/main/resources/index-mapping.xml", "nameBasicsFile", "name_basics");
		esLoader.shutdown();
	}
	
	private void buildEsClient() {
		
		final CredentialsProvider credentialsProvider =
			    new BasicCredentialsProvider();
			credentialsProvider.setCredentials(AuthScope.ANY,
			    new UsernamePasswordCredentials("elastic", "ready2go"));
			
		// Create the low-level client
		RestClient restClient = RestClient.builder(
		    new HttpHost("localhost", 9200))
				.setHttpClientConfigCallback(config -> config.setDefaultCredentialsProvider(credentialsProvider))
				.build();

		// Create the transport with a Jackson mapper
		ElasticsearchTransport transport = new RestClientTransport(
		    restClient, new JacksonJsonpMapper());

		// And create the API client
		esClient = new ElasticsearchClient(transport);
		
	}
	
	private void shutdown() {
		esClient.shutdown();
		System.exit(0);
	}
	
	@SuppressWarnings("unused")
	private void loadFromFile_1(String fileName, String streamMapping, String streamName, String indexName) throws ElasticsearchException, IOException {
	
			BulkProcessor.Builder processBuilder = new BulkProcessor.Builder(esClient, new BulkProcessor.Listener() {
				
				@Override
				public void beforeBulk(long executionId, BulkRequest request) {
					logger.info("Before executing bulk {}", executionId);
				}
				
				@Override
				public void afterBulk(long executionId, BulkRequest request, Throwable failure) {
					logger.error("Error while executing bulk {}", executionId, failure);
				}
				
				@Override
				public void afterBulk(long executionId, BulkRequest request, BulkResponse response) {
					logger.info("Execution completed for bulk {}", executionId);
					// Log errors, if any
				     if (response.errors()) {
				         for (BulkResponseItem item: response.items()) {
				             if (item.error() != null) {
				                 logger.error(item.error().reason());
				             }
				         }
				     }
				}
			});
			
			BulkProcessor bulkProcessor = processBuilder
					.setName("es-loader")
					.setConcurrentRequests(4)
					.setBulkActions(500).build();
		
			// create a StreamFactory
	        StreamFactory factory = StreamFactory.newInstance();
	        // load the mapping file
	        factory.load(streamMapping);
	        
	        Reader reader = new InputStreamReader(new FileInputStream(new File(fileName)), StandardCharsets.UTF_8);
	        // use a StreamFactory to create a BeanReader
	        BeanReader in = factory.createReader(streamName, reader);
	        
	        IndexAware tempBean;
	        int i = 0;
	        // Skip First Record
	        in.skip(1);
	        //i < 100 && 
	        while ((tempBean = (IndexAware) in.read()) != null) {
	            // process the employee...
	        	//logger.info(">>{} - {}",i, tempBean);
	        	//*
	        	final IndexAware indexAwareBean = tempBean;
	        	bulkProcessor.add(op -> op           
        	        .index(idx -> {
    	        		idx.index(indexName)       
    	        			.id(indexAwareBean.getId())
    	        			.document(indexAwareBean);
    	        		//if(indexAwareBean.hasParent()) {
    	        		//}
    	        			return idx;
    	        	})
	        	);
	    	    //*/
	        	i++;
	        }
	        in.close();
	        
	        try {
				bulkProcessor.awaitClose(100, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
	}
	
	@SuppressWarnings("unused")
	private void loadFromFile_2(String fileName, String streamMapping, String streamName, String indexName) throws ElasticsearchException, IOException {
		
		BulkRequest.Builder br = new BulkRequest.Builder();
		
		// create a StreamFactory
        StreamFactory factory = StreamFactory.newInstance();
        // load the mapping file
        factory.load(streamMapping);
        
        Reader reader = new InputStreamReader(new FileInputStream(new File(fileName)), StandardCharsets.UTF_8);
        // use a StreamFactory to create a BeanReader
        BeanReader in = factory.createReader(streamName, reader);
        
        IndexAware tempBean;
        int i = 0;
        // Skip First Record
        in.skip(1);
        while (i < 100 && (tempBean = (IndexAware) in.read()) != null) {
            // process the employee...
        	logger.info(">> {}", tempBean);
        	//System.out.println(akasTemp);
        	//*
        	final IndexAware indexAwareBean = tempBean;
        	br.operations(op -> op           
    	        .index(idx -> {
    	        		idx.index(indexName)       
    	        			.id(indexAwareBean.getId())
    	        			.document(indexAwareBean);
    	        		//if(indexAwareBean.hasParent()) {
    	        		//}
    	        		return idx;
    	        	}
    	        )
    	    );
    	    //*/
        	i++;
        }
        in.close();
        //*
        BulkResponse result = esClient.bulk(br.build());
	
	     // Log errors, if any
	     if (result.errors()) {
	         //logger.error("Bulk had errors");
	         for (BulkResponseItem item: result.items()) {
	             if (item.error() != null) {
	                 logger.error(item.error().reason());
	             }
	         }
	     }
		//*/
	}
}
