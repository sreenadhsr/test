package org.esloader.beanio.types.handler;

import org.beanio.types.TypeConversionException;
import org.beanio.types.TypeHandler;

public class BinaryBooleanTypeHaldner implements TypeHandler {

	
	public Object parse(String text) throws TypeConversionException {
		return "1".equals(text);
	}

	public String format(Object value) {
		return value != null && ((Boolean)value).booleanValue() ? "1" : "0";
	}

	public Class<?> getType() {
		return Boolean.class;
	}

}
