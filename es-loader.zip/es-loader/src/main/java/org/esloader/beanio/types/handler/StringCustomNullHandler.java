package org.esloader.beanio.types.handler;

import java.util.Objects;

import org.beanio.types.TypeConversionException;
import org.beanio.types.TypeHandler;

public class StringCustomNullHandler implements TypeHandler{
	
	private String nullValue = "\\0";  

	public Object parse(String text) throws TypeConversionException {
		return nullValue.equals(text) ? null : text;
	}

	public String format(Object value) {
		return Objects.isNull(value) ? nullValue : String.valueOf(value);
	}

	public Class<?> getType() {
		return String.class;
	}

	public String getNullValue() {
		return nullValue;
	}

	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}

}
