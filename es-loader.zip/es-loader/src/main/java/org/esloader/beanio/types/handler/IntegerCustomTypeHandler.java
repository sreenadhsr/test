package org.esloader.beanio.types.handler;

import org.beanio.types.IntegerTypeHandler;

public class IntegerCustomTypeHandler extends IntegerTypeHandler {
	
	private String nullValue = "\\0";  

	@Override
	protected Integer createNumber(String text) throws NumberFormatException {
		if(nullValue.equals(text)) return null;
		return super.createNumber(text);
	}

	public String getNullValue() {
		return nullValue;
	}

	public void setNullValue(String nullValue) {
		this.nullValue = nullValue;
	}
	
	
}
