package org.esloader.common;

import org.esloader.elasticsearch.ElasticsearchException;

/**
 * A generic failure to handle settings.
 *
 *
 */
public class SettingsException extends ElasticsearchException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SettingsException(String message) {
        super(message);
    }

    public SettingsException(String message, Throwable cause) {
        super(message, cause);
    }

}