package org.esloader.common;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.esloader.elasticsearch.common.util.concurrent.EsExecutors;

public class CompositeExecutorService implements ExecutorService {

	int MAX_THREAD_COUNT = 10;
	private ExecutorService sharedExecutorService = Executors.newFixedThreadPool(MAX_THREAD_COUNT, EsExecutors.daemonThreadFactory("es-loader"));
	
	private static CompositeExecutorService compositeExecutorService = new CompositeExecutorService();
	
	private CompositeExecutorService() {
	}
	
	public static CompositeExecutorService getCompositeExecutorService() {
		return compositeExecutorService;
	}
	
	@Override
	public void execute(Runnable command) {
		sharedExecutorService.execute(command);
	}

	@Override
	public void shutdown() {
		throw new UnsupportedOperationException("Unsupported operation for CompositeExecutorService");
		
	}

	@Override
	public List<Runnable> shutdownNow() {
		throw new UnsupportedOperationException("Unsupported operation for CompositeExecutorService");
	}

	@Override
	public boolean isShutdown() {
		return sharedExecutorService.isShutdown();
	}

	@Override
	public boolean isTerminated() {
		return sharedExecutorService.isTerminated();
	}

	@Override
	public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
		return sharedExecutorService.awaitTermination(timeout, unit);
	}

	@Override
	public <T> Future<T> submit(Callable<T> task) {
		return sharedExecutorService.submit(task);
	}

	@Override
	public <T> Future<T> submit(Runnable task, T result) {
		return sharedExecutorService.submit(task, result);
	}

	@Override
	public Future<?> submit(Runnable task) {
		return sharedExecutorService.submit(task);
	}

	@Override
	public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks) throws InterruptedException {
		return sharedExecutorService.invokeAll(tasks);
	}

	@Override
	public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
			throws InterruptedException {
		return sharedExecutorService.invokeAll(tasks, timeout, unit);
	}

	@Override
	public <T> T invokeAny(Collection<? extends Callable<T>> tasks) throws InterruptedException, ExecutionException {
		return sharedExecutorService.invokeAny(tasks);
	}

	@Override
	public <T> T invokeAny(Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
			throws InterruptedException, ExecutionException, TimeoutException {
		return sharedExecutorService.invokeAny(tasks, timeout, unit);
	}

	
	
}
