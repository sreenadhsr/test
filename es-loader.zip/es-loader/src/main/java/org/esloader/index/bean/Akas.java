package org.esloader.index.bean;

import java.util.List;
import java.util.StringJoiner;

import org.apache.logging.log4j.util.Strings;

public class Akas implements IndexAware{
	
	private String titleId;
	private int ordering;
	private String title;
	private String region;
	private String language;
	private List<String> types;
	private List<String> attributes;
	private boolean isOriginalTitle;
	
	public String getTitleId() {
		return titleId;
	}
	public void setTitleId(String titleId) {
		this.titleId = titleId;
	}
	public int getOrdering() {
		return ordering;
	}
	public void setOrdering(int ordering) {
		this.ordering = ordering;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<String> getTypes() {
		return types;
	}
	public void setTypes(List<String> types) {
		this.types = types;
	}
	public List<String> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<String> attributes) {
		this.attributes = attributes;
	}
	public boolean isOriginalTitle() {
		return isOriginalTitle;
	}
	public void setOriginalTitle(boolean isOriginalTitle) {
		this.isOriginalTitle = isOriginalTitle;
	}
	
	@Override
	public String toString() {
		return "Akas [titleId=" + titleId + ", ordering=" + ordering + ", title=" + title + ", region=" + region
				+ ", language=" + language + ", types=" + types + ", attributes=" + attributes + ", isOriginalTitle="
				+ isOriginalTitle + "]";
	}
	
	@Override
	public String getId() {
		return null;
	}

}
