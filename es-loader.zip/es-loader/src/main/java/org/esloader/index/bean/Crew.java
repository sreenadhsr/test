package org.esloader.index.bean;

import java.util.List;

public class Crew implements IndexAware {

	private String tconst;
	private List<String> directors;
	private List<String> writers;
	
	public String getTconst() {
		return tconst;
	}
	public void setTconst(String tconst) {
		this.tconst = tconst;
	}
	public List<String> getDirectors() {
		return directors;
	}
	public void setDirectors(List<String> directors) {
		this.directors = directors;
	}
	public List<String> getWriters() {
		return writers;
	}
	public void setWriters(List<String> writers) {
		this.writers = writers;
	}
	
	@Override
	public String toString() {
		return "Crew [tconst=" + tconst + ", directors=" + directors + ", writers=" + writers + "]";
	}

	@Override
	public String getId() {
		return this.getTconst();
	}
}
