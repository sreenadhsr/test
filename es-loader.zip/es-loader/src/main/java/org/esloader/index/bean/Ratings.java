package org.esloader.index.bean;

public class Ratings implements IndexAware {

	private String tconst;
	private Float averageRating;
	private Integer numVotes;
	
	public String getTconst() {
		return tconst;
	}
	public void setTconst(String tconst) {
		this.tconst = tconst;
	}
	public Float getAverageRating() {
		return averageRating;
	}
	public void setAverageRating(Float averageRating) {
		this.averageRating = averageRating;
	}
	public Integer getNumVotes() {
		return numVotes;
	}
	public void setNumVotes(Integer numVotes) {
		this.numVotes = numVotes;
	}
	
	@Override
	public String toString() {
		return "Ratings [tconst=" + tconst + ", averageRating=" + averageRating + ", numVotes=" + numVotes + "]";
	}
	
	@Override
	public String getId() {
		return this.getTconst();
	}
}
