package org.esloader.index.action;

import java.util.function.Function;

import co.elastic.clients.elasticsearch.core.bulk.BulkOperation;
import co.elastic.clients.util.ObjectBuilder;

@FunctionalInterface
public interface AddBulkOperation {

	BulkProcessor add(Function<BulkOperation.Builder, ObjectBuilder<BulkOperation>> fn);
}
