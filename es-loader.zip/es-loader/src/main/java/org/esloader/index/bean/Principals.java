package org.esloader.index.bean;

public class Principals implements IndexAware {

	private String tconst;
	private Integer ordering;
	private String nconst;
	private String category;
	private String job;
	private String characters;
	
	public String getTconst() {
		return tconst;
	}
	public void setTconst(String tconst) {
		this.tconst = tconst;
	}
	public Integer getOrdering() {
		return ordering;
	}
	public void setOrdering(Integer ordering) {
		this.ordering = ordering;
	}
	public String getNconst() {
		return nconst;
	}
	public void setNconst(String nconst) {
		this.nconst = nconst;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getCharacters() {
		return characters;
	}
	public void setCharacters(String characters) {
		this.characters = characters;
	}
	
	@Override
	public String toString() {
		return "Principals [tconst=" + tconst + ", ordering=" + ordering + ", nconst=" + nconst + ", category="
				+ category + ", job=" + job + ", characters=" + characters + "]";
	}
	
	@Override
	public String getId() {
		return this.getTconst();
	}
	
}
