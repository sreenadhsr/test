package org.esloader.index.bean;

public interface IndexAware {
	
	String getId();
	
	default boolean hasParent() {
		return false;
	}
	
	default String getParentId() {
		return null;
	}
}
