package org.esloader.index.bean;

import java.util.List;

public class NameBasics implements IndexAware {
	
	private String nconst;
	private String primaryName;
	private Integer birthYear;
	private Integer deathYear;
	private List<String> primaryProfession;
	private List<String> knownForTitles;
	
	public String getNconst() {
		return nconst;
	}
	public void setNconst(String nconst) {
		this.nconst = nconst;
	}
	public String getPrimaryName() {
		return primaryName;
	}
	public void setPrimaryName(String primaryName) {
		this.primaryName = primaryName;
	}
	public Integer getBirthYear() {
		return birthYear;
	}
	public void setBirthYear(Integer birthYear) {
		this.birthYear = birthYear;
	}
	public Integer getDeathYear() {
		return deathYear;
	}
	public void setDeathYear(Integer deathYear) {
		this.deathYear = deathYear;
	}
	public List<String> getPrimaryProfession() {
		return primaryProfession;
	}
	public void setPrimaryProfession(List<String> primaryProfession) {
		this.primaryProfession = primaryProfession;
	}
	public List<String> getKnownForTitles() {
		return knownForTitles;
	}
	public void setKnownForTitles(List<String> knownForTitles) {
		this.knownForTitles = knownForTitles;
	}
	
	@Override
	public String toString() {
		return "NameBasics [nconst=" + nconst + ", primaryName=" + primaryName + ", birthYear=" + birthYear
				+ ", deathYear=" + deathYear + ", primaryProfession=" + primaryProfession + ", knownForTitles="
				+ knownForTitles + "]";
	}
	
	@Override
	public String getId() {
		return this.getNconst();
	}
	
}
