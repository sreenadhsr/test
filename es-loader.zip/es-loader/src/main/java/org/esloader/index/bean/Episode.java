package org.esloader.index.bean;

public class Episode implements IndexAware {

	private String tconst;
	private String parentTconst;
	private Integer seasonNumber;
	private Integer episodeNumber;
	
	public String getTconst() {
		return tconst;
	}
	public void setTconst(String tconst) {
		this.tconst = tconst;
	}
	public String getParentTconst() {
		return parentTconst;
	}
	public void setParentTconst(String parentTconst) {
		this.parentTconst = parentTconst;
	}
	public Integer getSeasonNumber() {
		return seasonNumber;
	}
	public void setSeasonNumber(Integer seasonNumber) {
		this.seasonNumber = seasonNumber;
	}
	public Integer getEpisodeNumber() {
		return episodeNumber;
	}
	public void setEpisodeNumber(Integer episodeNumber) {
		this.episodeNumber = episodeNumber;
	}
	
	@Override
	public String toString() {
		return "Episode [tconst=" + tconst + ", parentTconst=" + parentTconst + ", seasonNumber=" + seasonNumber
				+ ", episodeNumber=" + episodeNumber + "]";
	}
	
	@Override
	public String getId() {
		return this.getTconst();
	}
	
	@Override
	public boolean hasParent() {
		return true; 
	}
	
	@Override
	public String getParentId() {
		return this.getParentTconst();
	}
}
