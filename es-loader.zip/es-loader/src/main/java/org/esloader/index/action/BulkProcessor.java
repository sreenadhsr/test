package org.esloader.index.action;

import java.io.Closeable;
import java.io.IOException;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;

import javax.annotation.Nullable;

import org.esloader.common.CompositeExecutorService;
import org.esloader.common.Settings;
import org.esloader.elasticsearch.ElasticsearchException;
import org.esloader.elasticsearch.common.util.concurrent.EsExecutors;
import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.BulkRequest;
import co.elastic.clients.elasticsearch.core.BulkResponse;
import co.elastic.clients.elasticsearch.core.bulk.BulkOperation;
import co.elastic.clients.util.ObjectBuilder;

/**
 * A bulk processor is a thread safe bulk processing class, allowing to easily set when to "flush" a new bulk request
 * (either based on number of actions, based on the size, or time), and to easily control the number of concurrent bulk
 * requests allowed to be executed in parallel.
 * In order to create a new bulk processor, use the {@link Builder}.
 */
public class BulkProcessor implements Closeable, AddBulkOperation {

    /**
     * A listener for the execution.
     */
    public interface Listener {

        /**
         * Callback before the bulk is executed.
         * @param executionId execution ID
         * @param request request
         */
        void beforeBulk(long executionId, BulkRequest request);

        /**
         * Callback after a successful execution of bulk request.
         * @param executionId execution ID
         * @param request request
         * @param response response
         */
        void afterBulk(long executionId, BulkRequest request, BulkResponse response);

        /**
         * Callback after a failed execution of bulk request.
         *
         * Note that in case an instance of <code>InterruptedException</code> is passed, which means that request processing has been
         * cancelled externally, the thread's interruption status has been restored prior to calling this method.
         * @param executionId execution ID
         * @param request request
         * @param failure failure
         */
        void afterBulk(long executionId, BulkRequest request, Throwable failure);
    }

    /**
     * A builder used to create a build an instance of a bulk processor.
     */
    public static class Builder {

        private final ElasticsearchClient client;
        private final Listener listener;
        private String name;
        private int concurrentRequests = 1;
        private int bulkActions = 1000;
        private Duration flushInterval = null;
        private Settings settings = null;

        /**
         * Creates a builder of bulk processor with the client to use and the listener that will be used
         * to be notified on the completion of bulk requests.
         * @param client the client
         * @param listener the listener
         */
        public Builder(ElasticsearchClient client, Listener listener) {
            this.client = client;
            this.listener = listener;
        }

        /**
         * Sets an optional name to identify this bulk processor.
         * @param name name
         * @return this builder
         */
        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        /**
         * Sets the number of concurrent requests allowed to be executed. A value of 0 means that only a single
         * request will be allowed to be executed. A value of 1 means 1 concurrent request is allowed to be executed
         * while accumulating new bulk requests. Defaults to <tt>1</tt>.
         * @param concurrentRequests maximum number of concurrent requests
         * @return this builder
         */
        public Builder setConcurrentRequests(int concurrentRequests) {
            this.concurrentRequests = concurrentRequests;
            return this;
        }

        /**
         * Sets when to flush a new bulk request based on the number of actions currently added. Defaults to
         * <tt>1000</tt>. Can be set to <tt>-1</tt> to disable it.
         * @param bulkActions mbulk actions
         * @return this builder
         */
        public Builder setBulkActions(int bulkActions) {
            this.bulkActions = bulkActions;
            return this;
        }

        /**
         * Sets a flush interval flushing *any* bulk actions pending if the interval passes. Defaults to not set.
         * @param flushInterval flush interval
         * @return this builder
         */
        public Builder setFlushInterval(Duration flushInterval) {
            this.flushInterval = flushInterval;
            return this;
        }

        public Builder setSettings(Settings settings) {
            this.settings = settings;
            return this;
        }
        
        /**
         * Builds a new bulk processor.
         * @return a bulk processor
         */
        public BulkProcessor build() {
            return new BulkProcessor(client, listener, name, concurrentRequests, bulkActions, flushInterval, settings);
        }
    }

    public static Builder builder(ElasticsearchClient client, Listener listener) {
        if (client == null) {
            throw new NullPointerException("The client you specified while building a BulkProcessor is null");
        }
        return new Builder(client, listener);
    }

    private final int bulkActions;

    private final ScheduledThreadPoolExecutor scheduler;
    private final ScheduledFuture<?> scheduledFuture;

    private final AtomicLong executionIdGen = new AtomicLong();
    private final AtomicInteger operationsCount = new AtomicInteger(0);

    private BulkRequest.Builder bulkRequestBuilder;
    private final BulkRequestHandler bulkRequestHandler;

    private volatile boolean closed = false;

	BulkProcessor(ElasticsearchClient client, Listener listener, @Nullable String name, int concurrentRequests,
			int bulkActions, @Nullable Duration flushInterval, Settings settings) {
        this.bulkActions = bulkActions;

        this.bulkRequestBuilder = new BulkRequest.Builder();
        this.bulkRequestHandler = concurrentRequests == 0 ?
                new SyncBulkRequestHandler(client, listener) :
                new AsyncBulkRequestHandler(client, listener, concurrentRequests);

        
        if (flushInterval != null) {
            this.scheduler = (ScheduledThreadPoolExecutor) Executors.newScheduledThreadPool(1, EsExecutors.daemonThreadFactory(settings, (name != null ? "[" + name + "]" : "") + "bulk_processor"));
            this.scheduler.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
            this.scheduler.setContinueExistingPeriodicTasksAfterShutdownPolicy(false);
            this.scheduledFuture = this.scheduler.scheduleWithFixedDelay(new Flush(), flushInterval.toMillis(), flushInterval.toMillis(), TimeUnit.MILLISECONDS);
        } else {
            this.scheduler = null;
            this.scheduledFuture = null;
        }
    }

    /**
     * Closes the processor. If flushing by time is enabled, then it's shutdown. Any remaining bulk actions are flushed.
     */
    @Override
    public void close() {
        try {
            awaitClose(0, TimeUnit.NANOSECONDS);
        } catch(InterruptedException exc) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Closes the processor. If flushing by time is enabled, then it's shutdown. Any remaining bulk actions are flushed.
     *
     * If concurrent requests are not enabled, returns {@code true} immediately.
     * If concurrent requests are enabled, waits for up to the specified timeout for all bulk requests to complete then returns {@code true},
     * If the specified waiting time elapses before all bulk requests complete, {@code false} is returned.
     *
     * @param timeout The maximum time to wait for the bulk requests to complete
     * @param unit The time unit of the {@code timeout} argument
     * @return {@code true} if all bulk requests completed and {@code false} if the waiting time elapsed before all the bulk requests completed
     * @throws InterruptedException If the current thread is interrupted
     */
    public synchronized boolean awaitClose(long timeout, TimeUnit unit) throws InterruptedException {
        if (closed) {
            return true;
        }
        closed = true;
        if (this.scheduledFuture != null) {
            this.scheduledFuture.cancel(false);
            this.scheduler.shutdown();
        }
        if (operationsCount.get() > 0) {
            execute();
        }
        return this.bulkRequestHandler.awaitClose(timeout, unit);
    }

    public synchronized BulkProcessor add(Function<BulkOperation.Builder, ObjectBuilder<BulkOperation>> fn) {
    	ensureOpen();
    	bulkRequestBuilder.operations(fn.apply(new BulkOperation.Builder()).build());
    	operationsCount.incrementAndGet();
        executeIfNeeded();
    	return this;
    }

    protected void ensureOpen() {
        if (closed) {
            throw new IllegalStateException("bulk process already closed");
        }
    }

    private void executeIfNeeded() {
        ensureOpen();
        if (!isOverTheLimit()) {
            return;
        }
        execute();
    }

    private void execute() {
        final BulkRequest.Builder bulkRequest = this.bulkRequestBuilder;
        final long executionId = executionIdGen.incrementAndGet();
        
        operationsCount.set(0);
        this.bulkRequestBuilder = new BulkRequest.Builder();
        this.bulkRequestHandler.execute(bulkRequest.build(), executionId);
    }

    private boolean isOverTheLimit() {
        return bulkActions != -1 && operationsCount.get() >= bulkActions;
    }

    /**
     * Flush pending delete or index requests.
     */
    public synchronized void flush() {
        ensureOpen();
        if (operationsCount.get() > 0) {
            execute();
        }
    }

    class Flush implements Runnable {

        @Override
        public void run() {
            synchronized (BulkProcessor.this) {
                if (closed) {
                    return;
                }
                if (operationsCount.get() == 0) {
                    return;
                }
                execute();
            }
        }
    }

    /**
     * Abstracts the low-level details of bulk request handling
     */
    abstract class BulkRequestHandler {

        public abstract void execute(BulkRequest bulkRequest, long executionId);

        public abstract boolean awaitClose(long timeout, TimeUnit unit) throws InterruptedException;

    }

    class SyncBulkRequestHandler extends BulkRequestHandler {
        private final ElasticsearchClient client;
        private final BulkProcessor.Listener listener;

        public SyncBulkRequestHandler(ElasticsearchClient client, BulkProcessor.Listener listener) {
            this.client = client;
            this.listener = listener;
        }

        public void execute(BulkRequest bulkRequest, long executionId) {
            boolean afterCalled = false;
            try {
                listener.beforeBulk(executionId, bulkRequest);
                BulkResponse bulkResponse = client.bulk(bulkRequest);
                afterCalled = true;
                listener.afterBulk(executionId, bulkRequest, bulkResponse);
            } catch (Throwable t) {
                if (!afterCalled) {
                    listener.afterBulk(executionId, bulkRequest, t);
                }
            }
        }

        public boolean awaitClose(long timeout, TimeUnit unit) throws InterruptedException {
            return true;
        }
    }

    class AsyncBulkRequestHandler extends BulkRequestHandler {
        private final ElasticsearchClient client;
        private final BulkProcessor.Listener listener;
        private final Semaphore semaphore;
        private final int concurrentRequests;

        private AsyncBulkRequestHandler(ElasticsearchClient client, BulkProcessor.Listener listener, int concurrentRequests) {
            this.client = client;
            this.listener = listener;
            this.concurrentRequests = concurrentRequests;
            this.semaphore = new Semaphore(concurrentRequests);
        }

        @Override
        public void execute(final BulkRequest bulkRequest, final long executionId) {
            boolean bulkRequestSetupSuccessful = false;
            boolean acquired = false;
            try {
                listener.beforeBulk(executionId, bulkRequest);
                semaphore.acquire();
                acquired = true;

                CompletableFuture.supplyAsync(() -> {
					try {
						return client.bulk(bulkRequest);
					} catch (ElasticsearchException | IOException e) {
						throw new CompletionException(e); 
					}
				}, CompositeExecutorService.getCompositeExecutorService())
                .whenCompleteAsync((response, ex) -> {
                	try {
	                	if(Objects.nonNull(ex)) {
	                		 listener.afterBulk(executionId, bulkRequest, ex);
	                	} else {
	                		 listener.afterBulk(executionId, bulkRequest, response);
	                	}
                	}finally {
                		semaphore.release();
                	}
                });
                
                bulkRequestSetupSuccessful = true;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                listener.afterBulk(executionId, bulkRequest, e);
            } catch (Throwable t) {
                listener.afterBulk(executionId, bulkRequest, t);
            } finally {
                if (!bulkRequestSetupSuccessful && acquired) {  // if we fail on client.bulk() release the semaphore
                    semaphore.release();
                }
            }
        }

        @Override
        public boolean awaitClose(long timeout, TimeUnit unit) throws InterruptedException {
            if (semaphore.tryAcquire(this.concurrentRequests, timeout, unit)) {
                semaphore.release(this.concurrentRequests);
                return true;
            }
            return false;
        }
    }
}
