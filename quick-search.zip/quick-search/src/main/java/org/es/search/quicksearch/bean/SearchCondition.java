package org.es.search.quicksearch.bean;

import com.fasterxml.jackson.annotation.JsonValue;

public enum SearchCondition {
	AND("and"), OR("or"),NOT("not"),EXISTS("exists");
	
	SearchCondition(String condition) {
		this.condition = condition;
	}

	@JsonValue
	private String condition;
	
	public static SearchCondition getSearchCondition(String condition) {
		for(SearchCondition searchCondition: values()) {
			if(searchCondition.condition.equals(condition)) {
				return searchCondition;
			}
		}
		return null;
	}

	public String getCondition() {
		return condition;
	}
	
}
