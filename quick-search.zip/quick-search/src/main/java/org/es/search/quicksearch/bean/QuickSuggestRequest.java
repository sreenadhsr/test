package org.es.search.quicksearch.bean;

import java.util.List;

public class QuickSuggestRequest {
	
	private String text;
	private int size;
	private List<String> source;
	private List<String> fields;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public List<String> getSource() {
		return source;
	}
	public void setSource(List<String> source) {
		this.source = source;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}

	@Override
	public String toString() {
		return "QuickSuggestRequest [text=" + text + ", size=" + size + ", source=" + source + ", fields=" + fields
				+ "]";
	}
	
}
