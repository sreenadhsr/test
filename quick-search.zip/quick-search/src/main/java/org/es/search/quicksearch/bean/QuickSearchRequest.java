package org.es.search.quicksearch.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuickSearchRequest {
	
	private int size;
	private List<String> source; 
	private List<QueryObject> queryObjects;
	private List<String> includes;
	private List<String> excludes;
	
	@JsonProperty("queryObject")
	public List<QueryObject> getQueryObjects() {
		return queryObjects;
	}

	public void setQueryObjects(List<QueryObject> queryObjects) {
		this.queryObjects = queryObjects;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public List<String> getSource() {
		return source;
	}
	public void setSource(List<String> source) {
		this.source = source;
	}

	public List<String> getIncludes() {
		return includes;
	}

	public void setIncludes(List<String> includes) {
		this.includes = includes;
	}

	public List<String> getExcludes() {
		return excludes;
	}

	public void setExcludes(List<String> excludes) {
		this.excludes = excludes;
	}

	@Override
	public String toString() {
		return "QuickSearchRequest [size=" + size + ", source=" + source + ", queryObjects=" + queryObjects
				+ ", includes=" + includes + ", exclude=" + excludes + "]";
	}

}
