package org.es.search.quicksearch.exception;

public class QuickSearchException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public QuickSearchException(String message) {
		super(message);
	}
	
	public QuickSearchException(Throwable t) {
		super(t);
	}
	
	public QuickSearchException(String message, Throwable t) {
		super(message, t);
	}
	
}
