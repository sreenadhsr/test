package org.es.search.quicksearch.bean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

import co.elastic.clients.json.JsonpMapper;
import co.elastic.clients.json.JsonpSerializable;
import co.elastic.clients.json.JsonpUtils;
import jakarta.json.stream.JsonGenerator;

public class SourceFieldMapper implements JsonpSerializable {

	private Map<String, Object> fields = new HashMap<String, Object>();
	
	@JsonAnyGetter
	public Map<String, Object> getFields() {
		return fields;
	}

	@JsonAnySetter
    public void add(String key, Object value) {
		fields.put(key, value);
    }
	
	@Override
	public String toString() {
		return JsonpUtils.toString(this);
	}

	public void serialize(JsonGenerator generator, JsonpMapper mapper) {
		if(Objects.nonNull(fields)) {
			generator.writeStartObject();
			fields.forEach((k,v) -> {
				generator.writeKey(k);
				if(v instanceof List) {
					generator.writeStartArray();
					List<?> vlist = (List<?>) v;
					vlist.forEach(item -> this.writeValue(generator, item));
					generator.writeEnd();
				} else {
					generator.write(String.valueOf(v));	
				}
			});
			generator.writeEnd();
		}
	}
	
	private void writeValue(JsonGenerator generator, Object value) {
		if(Objects.isNull(value)) {
			generator.writeNull();
		} else if(String.class.isAssignableFrom(value.getClass())) {
			generator.write(value.toString());
		} else if(Integer.class.isAssignableFrom(value.getClass())) {
			generator.write(Integer.valueOf(value.toString()).intValue());
		} else if(Boolean.class.isAssignableFrom(value.getClass())) {
			generator.write(Boolean.valueOf(value.toString()).booleanValue());
		} else if(Double.class.isAssignableFrom(value.getClass())) {
			generator.write(Double.valueOf(value.toString()).doubleValue());
		} else if(Float.class.isAssignableFrom(value.getClass())) {
			generator.write(Float.valueOf(value.toString()).floatValue());
		} else {
			generator.write(value.toString());
		}
	}
}
