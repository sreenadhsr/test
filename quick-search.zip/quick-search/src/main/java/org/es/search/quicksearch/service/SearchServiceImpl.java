package org.es.search.quicksearch.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.http.HttpHost;
import org.es.search.quicksearch.bean.QuickSearchRequest;
import org.es.search.quicksearch.bean.QuickSearchResponse;
import org.es.search.quicksearch.bean.QuickSuggestRequest;
import org.es.search.quicksearch.bean.SearchCondition;
import org.es.search.quicksearch.bean.SearchOperation;
import org.es.search.quicksearch.bean.SourceFieldMapper;
import org.es.search.quicksearch.exception.QuickSearchException;
import org.es.search.quicksearch.util.ElasticsearchClientWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery.Builder;
import co.elastic.clients.elasticsearch._types.query_dsl.MultiMatchQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryBuilders;
import co.elastic.clients.elasticsearch.core.SearchRequest;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.CompletionSuggester;
import co.elastic.clients.elasticsearch.core.search.SourceConfig;
import co.elastic.clients.elasticsearch.core.search.Suggester;

@Service
public class SearchServiceImpl implements SearchService{


	protected static Logger logger = LoggerFactory.getLogger(SearchServiceImpl.class);
	
	private ElasticsearchClient esClient;
	
	private Predicate<SearchOperation> isFieldSufixRequired =  so -> so == SearchOperation.BW || so == SearchOperation.EW;
	
	@PostConstruct
	protected void init() {
		
		ElasticsearchClientWrapper.init("elastic", "ready2go", new HttpHost("localhost", 9200));
		esClient = ElasticsearchClientWrapper.getElasticsearchClient();
		
	}
	
	@Override
	public String search (QuickSearchRequest request) throws QuickSearchException {

		
		SearchRequest.Builder requestBuilder = new SearchRequest.Builder();
		
		// TODO lookup actual index name from source 
		requestBuilder.index(request.getSource());
		
		Builder boolQueryBuilder = QueryBuilders.bool();
		
		//TODO more than one query object
		request.getQueryObjects().stream().forEach(qo -> {
			
			List<Query> multiMatchQueries = new ArrayList<>();

			qo.getQueryList().stream().forEach(ql -> multiMatchQueries.add(MultiMatchQuery
					.of(mm -> mm.fields(this.getFields(ql.getFields(), ql.getOperation())).query(ql.getTerm()))._toQuery()));
			
			if(Objects.nonNull(qo.getCondition()) && qo.getCondition().equals(SearchCondition.OR)) {
				boolQueryBuilder.should(multiMatchQueries);
			} else {
				boolQueryBuilder.must(multiMatchQueries);
			}
			
		});
		
		//"_source" : false
		//requestBuilder.source(SourceConfig.of( s -> s.fetch(false)));
		//requestBuilder.fields(r -> r.field("primaryName"));
		/*
		 * TODO Instead of returning empty collection, we should default to the approved list of fields 
		 * of the requesting client
		 *  
		 */
		//*
		requestBuilder.source(SourceConfig.of(s -> s
				.filter(sf -> sf.includes(Optional.ofNullable(request.getIncludes()).orElse(Collections.emptyList()))
						.excludes(Optional.ofNullable(request.getExcludes()).orElse(Collections.emptyList())))));
		//*/
		SearchRequest searchRequest = requestBuilder.query(boolQueryBuilder.build()._toQuery()).build();
		//esClient.search(boolQueryBuilder.build(), Object.class);
		QuickSearchResponse response = null;
		SearchResponse<SourceFieldMapper> searchResponse = null; 
		String json = null;
		try {
			searchResponse = esClient.search(searchRequest, SourceFieldMapper.class);
			ObjectMapper mapper = ElasticsearchClientWrapper.getObjectMapper();
			response = mapper.readValue(String.valueOf(searchResponse), QuickSearchResponse.class);
			json = mapper.writeValueAsString(response);
			
		} catch (ElasticsearchException | IOException e) {
			throw new QuickSearchException(e);
		}
		
		return (Objects.nonNull(searchResponse) ? json : "ERROR");
	}

	private List<String> getFields(List<String> fields, SearchOperation searchOperation){
		
		return fields.stream()
				.map(f -> isFieldSufixRequired.test(searchOperation) ? f + "." + searchOperation.getOperation() : f)
				.collect(Collectors.toList());
	}

	
	@Override
	public String suggest(QuickSuggestRequest request) throws QuickSearchException {
		
		SearchRequest.Builder requestBuilder = new SearchRequest.Builder();
		
		// TODO lookup actual index name from source
		requestBuilder.index(request.getSource());
		
		Suggester.Builder suggesterBuilder = new Suggester.Builder();
		
		suggesterBuilder.text(request.getText()); // Global text used across all fields
		
		// TODO add support for multiple fields. We might need to pass a unique key name.
		request.getFields().forEach(field -> {
			final String suggestionFieldName = field.endsWith(".suggest") ? field : field + ".suggest";
			suggesterBuilder.suggesters("", f -> f
					.completion(CompletionSuggester.of(c -> c.field(suggestionFieldName).size(request.getSize()))));
		});
		
		/*
		Suggester suggester = Suggester.of(s -> s.text(request.getText())
				.suggesters("typeahead", f -> f.completion(c -> c.field(request.getFields().get(0)).size(request.getSize()))
		));
		*/
		
		SearchRequest searchRequest = requestBuilder.suggest(suggesterBuilder.build()).build();
		logger.info("{}", searchRequest);
		SearchResponse<Object> searchResponse = null; 
		try {
			searchResponse = esClient.search(searchRequest, Object.class);
			/*ObjectMapper mapper = ElasticsearchClientWrapper.getObjectMapper();
			response = mapper.readValue(String.valueOf(searchResponse), QuickSearchResponse.class);
			json = mapper.writeValueAsString(response);*/
			
		} catch (ElasticsearchException | IOException e) {
			throw new QuickSearchException(e);
		}
		
		return (Objects.nonNull(searchResponse) ? String.valueOf(searchResponse) : "ERROR");
	}
	
}
