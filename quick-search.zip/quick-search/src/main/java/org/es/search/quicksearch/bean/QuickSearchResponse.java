package org.es.search.quicksearch.bean;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Search response object. This is to extract required fields from original elasticsearch 
 * response and rename them. For e.g. change _source to source
 */
public class QuickSearchResponse {

    private Hits hits;

    public Hits getHits() {
        return hits;
    }

    private Map<String, Object> aggregations;

    public Map<String, Object> getAggregations() {
        return aggregations;
    }

    @Override
    public String toString() {
        return "QuickSearchResponse{" + "hits=" + hits +
                ", aggregations=" + aggregations +
                '}';
    }

    public static class Hits {

        private List<Hit> hits;

        private Total total;

        public List<Hit> getHits() {
            return hits;
        }
        
        @JsonProperty("total")
        public long getTotal() {
           return total.getValue();
        }
        
        @JsonProperty("total")
        public void setTotal(Total total) {
			this.total = total;
		}

		@Override
        public String toString() {
            String sb = "Hits{" + "hits=" + hits +
                    ", total=" + total +
                    '}';
            return sb;
        }
    }
    
    public static class Total {
    	long value;

		public long getValue() {
			return value;
		}

		public void setValue(long value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return "Total [value=" + value + "]";
		}
    }

    public static class Hit {

        @JsonProperty("_index")
        private String index;

        @JsonProperty("_type")
        private String type;

        @JsonProperty("_id")
        private String id;

        @JsonProperty("_version")
        private Long version;

        
        private Map<String, Object> sourceFields;

        private Map<String, List<String>> highlight;
        
        @JsonProperty("sourceFields")
        public Map<String, Object> getSourceFields() {
            return sourceFields;
        }
        
        @JsonProperty("_source")
        public void setSourceFields(Map<String, Object> sourceFields) {
			this.sourceFields = sourceFields;
		}

        /*
        public Map<String, Object> getFields() {
            return fields;
        }
         */
        public Map<String, List<String>> getHighlight() {
            return highlight;
        }

        public String getIndex() {
            return index;
        }

        public String getType() {
            return type;
        }

        public String getId() {
            return id;
        }

        public Long getVersion() {
            return version;
        }

        @Override
        public String toString() {
            return "Hit{" +
                    "index=" + index +
                    ", type=" + type +
                    ", id=" + id +
                    ", version=" + version +
                    ", sourceFields=" + sourceFields +
                    //", fields=" + fields +
                    ", highlight=" + highlight +
                    '}';
        }
    }
}
