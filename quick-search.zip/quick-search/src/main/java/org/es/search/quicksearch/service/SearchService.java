package org.es.search.quicksearch.service;

import org.es.search.quicksearch.bean.QuickSearchRequest;
import org.es.search.quicksearch.bean.QuickSuggestRequest;
import org.es.search.quicksearch.exception.QuickSearchException;

public interface SearchService {

	public String search (QuickSearchRequest request) throws QuickSearchException;
	public String suggest (QuickSuggestRequest suggest) throws QuickSearchException;
	
}
