package org.es.search.quicksearch.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QueryObject {
	private SearchCondition condition;
	
	@JsonProperty("query")
	private List<Query> queryList;

	public SearchCondition getCondition() {
		return condition;
	}

	public void setCondition(SearchCondition condition) {
		this.condition = condition;
	}

	public List<Query> getQueryList() {
		return queryList;
	}

	public void setQueryList(List<Query> queryList) {
		this.queryList = queryList;
	}

	@Override
	public String toString() {
		return "QueryObject [condition=" + condition + ", queryList=" + queryList + "]";
	}
}
