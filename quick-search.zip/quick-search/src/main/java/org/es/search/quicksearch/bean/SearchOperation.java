package org.es.search.quicksearch.bean;

import com.fasterxml.jackson.annotation.JsonValue;

public enum SearchOperation {
	EM ("exact-match"),
	BW ("begins-with"),
	EW ("ends-with"),
	CS ("contains"),
	NEM ("not-exact-match"),
	NBW ("not-begins-with"),
	NEW ("not-ends-with"),
	NCS ("not-contains");
	
	SearchOperation(String operation) {
		this.operation = operation;
	}
	
	@JsonValue
	private String operation;
	
	public static SearchOperation getSearchOperation(String operation) {
		for(SearchOperation searchOperation : values()) {
			if(searchOperation.operation.equals(operation)) {
				return searchOperation;
			}
		}
		return null;
	}

	public String getOperation() {
		return operation;
	}
	
}
