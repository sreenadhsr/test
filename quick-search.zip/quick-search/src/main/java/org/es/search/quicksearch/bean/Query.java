package org.es.search.quicksearch.bean;

import java.util.List;

public class Query {

	private String term;
	private SearchOperation operation;
	private List<String> fields;
	
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public SearchOperation getOperation() {
		return operation;
	}
	public void setOperation(SearchOperation operation) {
		this.operation = operation;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}
	
	@Override
	public String toString() {
		return "Query [term=" + term + ", operation=" + operation + ", fields=" + fields + "]";
	}
	
}
