package org.es.search.quicksearch.controller;

import java.util.UUID;

import org.es.search.quicksearch.bean.QuickSearchRequest;
import org.es.search.quicksearch.bean.QuickSuggestRequest;
import org.es.search.quicksearch.exception.QuickSearchException;
import org.es.search.quicksearch.service.SearchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QuickSearchController {

	private static Logger logger = LoggerFactory.getLogger(QuickSearchController.class);
	
	@Autowired
	private SearchService searchService;
	
	@PostMapping(path = "/search", consumes="application/json", produces = "application/json")
	public String search(@RequestBody QuickSearchRequest quickSearchRequest) {
		
		logger.info("{}" , quickSearchRequest);
		String response = "";
		try {
			response = searchService.search(quickSearchRequest);
		} catch (QuickSearchException e) {
			UUID randomUUID = UUID.randomUUID();
			logger.error("Exception while processing the reqest. Ref:" + randomUUID, e);
			return "{ \"status\" : \"error\", \"ref\": \""+ randomUUID + "\"}";
		}
		return response;
		//return "{ \"status\" : \"ok\"}";
	}
	
	
	@PostMapping(path = "/suggest", consumes="application/json", produces = "application/json")
	public String suggest(@RequestBody QuickSuggestRequest quickSuggestRequest) {
		
		logger.info("{}" , quickSuggestRequest);
		String response = "";
		try {
			response = searchService.suggest(quickSuggestRequest);
		} catch (QuickSearchException e) {
			UUID randomUUID = UUID.randomUUID();
			logger.error("Exception while processing the reqest. Ref:" + randomUUID, e);
			return "{ \"status\" : \"error\", \"ref\": \""+ randomUUID + "\"}";
		}
		return response;
		//return "{ \"status\" : \"ok\"}";
	}
	
	@GetMapping(path = "/", produces = "application/json")
	public String status() {
		return "Hello World!";
	}
}
