package org.es.search.quicksearch.util;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;

public class ElasticsearchClientWrapper {

	private static ElasticsearchClient esClient = null;
	
	private static final ObjectMapper mapper = new ObjectMapper();
	
	private ElasticsearchClientWrapper() {
	}

	public synchronized static void init(String username, String password, HttpHost... httpHosts) {
		if (httpHosts == null || httpHosts.length == 0) {
            throw new IllegalArgumentException("hosts must not be null nor empty");
        }
		
		RestClientBuilder builder = RestClient.builder(httpHosts);
		
		if(StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password)) {
			final CredentialsProvider credentialsProvider =
				    new BasicCredentialsProvider();
				credentialsProvider.setCredentials(AuthScope.ANY,
				    new UsernamePasswordCredentials(username, password));
				
				builder.setHttpClientConfigCallback(config -> config.setDefaultCredentialsProvider(credentialsProvider));
		}
		
		RestClient restClient = builder.build();
		
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
       
		// Create the transport with a Jackson mapper
		ElasticsearchTransport transport = new RestClientTransport(
		    restClient, new JacksonJsonpMapper(mapper));

		// And create the API client
		esClient = new ElasticsearchClient(transport);
		
	}
	
	public static ElasticsearchClient getElasticsearchClient() {
		if(!isInitialized()) {
			throw new IllegalStateException("You must call init() to initialize the client");
		}
		return esClient;
	}
	
	public static boolean isInitialized() {
		return Objects.nonNull(esClient);
	}
	
	public static ObjectMapper getObjectMapper() {
		return mapper;
	}
}
