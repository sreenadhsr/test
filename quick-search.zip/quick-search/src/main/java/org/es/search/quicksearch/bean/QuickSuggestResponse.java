package org.es.search.quicksearch.bean;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuickSuggestResponse {

	private Integer took;
	private Suggest suggest;
	
	
	public Integer getTook() {
		return took;
	}
	public void setTook(Integer took) {
		this.took = took;
	}
	public Suggest getSuggest() {
		return suggest;
	}
	public void setSuggest(Suggest suggest) {
		this.suggest = suggest;
	}

	@Override
	public String toString() {
		return "QuickSuggestResponse [took=" + took + ", suggest=" + suggest + "]";
	}


	public static class Suggest {
		
		@JsonProperty("")
		private List<Completion> completions;

		public List<Completion> getCompletions() {
			return completions;
		}

		public void setCompletions(List<Completion> completions) {
			this.completions = completions;
		}

		@Override
		public String toString() {
			return "Suggest [completions=" + completions + "]";
		}
		
	}
	
	public static class Completion {
		private Integer length;
		private Integer offset;
		private String text;
		private List<Option> option;
		public Integer getLength() {
			return length;
		}
		public Integer getOffset() {
			return offset;
		}
		public String getText() {
			return text;
		}
		public List<Option> getOption() {
			return option;
		}
		@Override
		public String toString() {
			return "Completion [length=" + length + ", offset=" + offset + ", text=" + text + ", option=" + option
					+ "]";
		}
	}
	
	
	public static class Option {

        @JsonProperty("_index")
        private String source;

        @JsonProperty("text")
        private String text;

        @JsonProperty("_id")
        private String id;

        private Map<String, Object> sourceFields;

        @JsonProperty("sourceFields")
        public Map<String, Object> getSourceFields() {
            return sourceFields;
        }
        
        @JsonProperty("_source")
        public void setSourceFields(Map<String, Object> sourceFields) {
			this.sourceFields = sourceFields;
		}

        public String getSource() {
            return source;
        }

        public String getId() {
            return id;
        }
        
        public String getText() {
			return text;
		}

		@Override
		public String toString() {
			return "Option [source=" + source + ", text=" + text + ", id=" + id + ", sourceFields=" + sourceFields
					+ "]";
		}
    }
}
