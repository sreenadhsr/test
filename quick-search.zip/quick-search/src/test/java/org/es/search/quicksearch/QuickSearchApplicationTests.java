package org.es.search.quicksearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
