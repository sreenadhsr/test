const express = require('express');
const https = require('https');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

function generateHeader(totalSize = 0, includeHeaders = true, includeCookie = false) {
    const headers = {};
    let headerBlock = '';
  
    const overhead = 200; // buffer for fixed headers like content-type, host, etc.
    const usableSize = Math.max(totalSize - overhead, 0);
  
    let headerSize = usableSize;
    let cookieSize = 0;
  
    if (includeHeaders && includeCookie) {
      headerSize = Math.floor(usableSize / 2);
      cookieSize = usableSize - headerSize;
    } else if (includeCookie) {
      headerSize = 0;
      cookieSize = usableSize;
    }
  
    // Generate large dummy headers
    if (includeHeaders && headerSize > 0) {
      const key = 'X-Large-Header';
      const val = 'A'.repeat(headerSize - key.length - 2); // account for ": " separator
      headers[key] = val;
    }
  
    // Generate large cookie
    if (includeCookie && cookieSize > 0) {
      const cookieVal = 'X_LARGE_VALUE=' + 'B'.repeat(cookieSize - 8); // "session=" length = 8
      headers['Cookie'] = cookieVal;
    }
  
    return headers;
  }
  
  

app.post('/send-request', (req, res) => {
    const { size, method, path: targetPath, body, hostname, port, truncate, optionalHeaders } = req.body;
    const httpMethod = (method || 'GET').toUpperCase();
    const requestBody = body || '';
    const shouldTruncate = truncate === 'truncate';
  
    const totalSizeBytes = Number(size) * 1024;

    const headers = {
        ...generateHeader(totalSizeBytes, req.body.includeLargeHeaders, req.body.includeLargeCookie),
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(requestBody),
        ...(optionalHeaders || {})
      };
      /*
      console.log('=== Incoming Request Configuration ===');
      console.log('Total Size:', size);
      console.log('Include Large Headers:', req.body.includeLargeHeaders);
      console.log('Include Large Cookie:', req.body.includeLargeCookie);
      console.log('Optional Headers:', optionalHeaders);
      console.log('\n=== Headers to be Sent ===');
      console.log(headers);
      */
      
    const requestLine = `${httpMethod} https://${hostname}${targetPath} HTTP/1.1`;
    const rawHeaders = Object.entries(headers)
      .map(([key, val]) => {
        const cleanVal = typeof val === 'string' ? val : JSON.stringify(val);
        return `${key}: ${shouldTruncate && cleanVal.length > 200 ? cleanVal.slice(0, 200) + '... [truncated]' : cleanVal}`;
      })
      .join('\n');
  
    const rawBody = shouldTruncate && requestBody.length > 1000
      ? requestBody.slice(0, 1000) + '... [truncated]'
      : requestBody;
  
    const options = {
      hostname,
      port: Number(port),
      path: targetPath || '/',
      method: httpMethod,
      headers,
      rejectUnauthorized: false,
    };
  
    const request = https.request(options, (response) => {
      let responseData = '';
      response.on('data', (chunk) => (responseData += chunk));
      response.on('end', () => {
        const result = `
  === RAW REQUEST ===
  ${requestLine}
  
  ${rawHeaders}
  
  ${rawBody ? '\nBody:\n' + rawBody : ''}
  
  === RESPONSE ===
  STATUS: ${response.statusCode}
  
  ${responseData}
  `;
        //res.send(result);
        res.json({
            result,            // Send the concatenated raw request/response string
            sizeBreakdown      // Include size breakdown information
          });
      });
    });
  
    request.on('error', (e) => {
      const errorOutput = `
  === RAW REQUEST ===
  ${requestLine}
  
  ${rawHeaders}
  
  ${rawBody ? '\nBody:\n' + rawBody : ''}
  
  === ERROR ===
  ${e.message}
  `;
    res.status(500).json({
        result: errorOutput,  // the error output message or string
        sizeBreakdown: {      // optional, you can set size breakdown to zero or null
          requestLineSize: 0,
          headersSize: 0,
          bodySize: 0,
          totalRequestSize: 0
        }
      });
    });
  
    if (['POST', 'PUT'].includes(httpMethod)) {
      request.write(requestBody);
    }
  
    // Estimate header size
    let rawHeaderBlock = '';
    for (const [key, value] of Object.entries(headers)) {
        rawHeaderBlock += `${key}: ${value}\r\n`;
    }

    const requestLine2 = `${method} ${targetPath} HTTP/1.1\r\n`;
    const rawRequest = requestLine2 + rawHeaderBlock + `\r\n` + requestBody;
    const totalRequestSize = Buffer.byteLength(rawRequest) + Buffer.byteLength(requestBody);

    const sizeBreakdown = {
        requestLineSize: Buffer.byteLength(requestLine),
        headersSize: Buffer.byteLength(rawHeaderBlock),
        bodySize: Buffer.byteLength(requestBody),
        totalRequestSize
    };
    // Log detailed size breakdown
    console.log('\n=== Request Size Breakdown ===');
    console.log('Request Line:', Buffer.byteLength(requestLine2), 'bytes');
    console.log('Headers:', Buffer.byteLength(rawHeaderBlock), 'bytes');
    console.log('Body:', Buffer.byteLength(requestBody), 'bytes');
    console.log('Total Estimated Request Size:', totalRequestSize, 'bytes');

    request.end();
  });
  
  
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

